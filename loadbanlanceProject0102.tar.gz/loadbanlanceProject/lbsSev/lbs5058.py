 #!/usr/bin/env python
#coding:utf-8
# import sys
# reload(sys)
# sys.setdefaultencoding( "utf-8" )
import tornado.httpserver
from tornado import websocket,gen,web#,httpclient
from tornado.ioloop import IOLoop
from datetime import datetime
from lib.getconf import getConfig
from lib.ipv4 import getip


import traceback
import json
import time
import os
##################algo
from core.lcompare import LCompare
    
#PYTHONPATH=$PYTHONPATH:/home/huang/project/zkx/face_node_GPU/interface
#/home/huang/project/zkx/face_node_GPU/interface
################## scan ip
# from core.lfollowers import *
# from core.lsevstatus import *
# Global_lojb        = LSevStatus(shost)
##################prepare

port =int( getConfig("RDS","Port"))
net_code = getConfig("NET","net_code")
debug =False
shost = getip(net_code)
Lcompare_lojb      = LCompare()
#count code lines 
#find . -name "*.py" -type f -exec grep . {} \; | wc -l


class BaseHandler(web.RequestHandler):
    def get(self):
        self.write_error(404)
    def write_error(self, status_code, **kwargs):
        if status_code == 404:
            self.render('static/404.html')
        elif status_code == 500:
            self.render('static/500.html')
        else:
            self.write('error:' + str(status_code))

class AcdHandler(web.RequestHandler):
    # def initialize(self):
    #     self.cache_rds = _cam_user

    # @gen.coroutine
    # def get(self):
    #     r= yield self.cache_rds.insNewAlarm(self)
    #     #print "the r is:",r
    #     self.write(json.dumps(r))

    @gen.coroutine
    def post(self):
        ResultCode ="true"
        ResultDesc =""
        try:
            data=json.loads(self.request.body)
            # print "damon!!!!!!the alarm center is",data
            r=yield self.cache_rds.insNewAlarm(data)
        except Exception as err:
            traceback.print_exc()
            ResultCode ="false"
            ResultDesc ="{}".format(err)
        t={
        "ResultCode":ResultCode,
        "ResultDesc":ResultDesc,
        }
        # print 'the TeamHandler r is',r
        self.write(t)

class CompareHandler(web.RequestHandler):
    # def initialize(self):
    #     self.cache_rds = _cam_user

    # @gen.coroutine
    # def get(self):
    #     r= yield self.cache_rds.insNewAlarm(self)
    #     #print "the r is:",r
    #     self.write(json.dumps(r))
    @gen.coroutine
    def get(self):
        self.write("""
        <form enctype="multipart/form-data" method="POST" action="compare">
          <table style="width: 100%">
            <tr>
              <td>Choose the files to upload:</td>
              <td style="text-align: right"><input type="file" multiple="" id="files" name="files"></td>
            </tr>
            <tr>
              <td><input id="fileUploadButton" type="submit" value="Upload >>"></td>
              <td></td>
            </tr>
          </table>
        </form>
            """)


    @gen.coroutine
    def post(self):
        ResultCode ="true"
        ResultDesc =""
        try:
            # data=json.loads(self.request.body)
            files  = []
            result = []
            # check whether the request contains files that should get uploaded
            try:
                files = self.request.files['files']
            except:
                pass
            # for each file that should get uploaded
            for xfile in files:
                # get the default file name
                file = xfile['filename']
                print "the filename is:",file
                # the filename should not contain any "evil" special characters
                # basically "evil" characters are all characters that allows you to break out from the upload directory
                index = file.rfind(".")
                filename = file[:index].replace(".", "") + str(time.time()).replace(".", "") + file[index:]
                filename = filename.replace("/", "")
                # save the file in the upload folder
                # with open("uploads/%s" % (filename), "w") as out:
                #   # Be aware, that the user may have uploaded something evil like an executable script ...
                #   # so it is a good idea to check the file content (xfile['body']) before saving the file
                #   out.write(xfile['body'])
                # data= self.request.body
                fea = yield gen.Task(Lcompare_lojb.get_feature,xfile['body'])
                result.append(fea)
                print "the get_feature is done",fea
            # print "damon!!!!!!the alarm center is",data
            # r=yield Global_lojb.compare_pic(data)
        except Exception as err:
            traceback.print_exc()
            ResultCode ="false"
            ResultDesc ="{}".format(err)
        t={
        "ResultCode":ResultCode,
        "ResultDesc":ResultDesc,
        "Result":str(result)
        }
        # print 'the TeamHandler r is',r
        self.write(t)
        # ... maybe add a check that checks whether the user is allowed to upload anything ...
        # the file(s) that should get uploaded
    ############

    # @app.route('/compare',methods=['POST',"GET"])
    # def receive():
    #     # pic = request.data
    #     # print "start to compare ......",request.method
    #     if request.method == 'POST':
    #         file1 =  request.files['file']
    #         # filename = secure_filename(file.filename)
    #         filename = file1.filename
    #         t=os.getcwd()
    #         file_dir = os.path.join(app.config['UPLOAD_FOLDER'],filename)
    #         r=file1.save(file_dir)
    #         mac_id = request.form['id']
    #     with open(file_dir,"rb") as f:
    #         pic = f.read()
    #         # print "len of pic is:",len(pic)
    #         image = np.fromstring(pic, dtype='uint8')
    #         image = cv2.imdecode(image, 1)
    #         print "\nthe file already read and the len of pic is:",len(pic),file_dir
    #     #os.remove(file_dir)
    #     # begin recognize
    #     global count_image
    #     # cv2.imwrite("./pics/from_net_feed_to_3399_" + str(count_image) + ".jpg", image)
    #     image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    #     count_image = count_image + 1
    #     ret = recognition_with_image(image)
    #     print("ret={}".format(ret))   
    #     data = None
    #     # 检测 到有黑白名单
    #     if ret is not None:
    #         if ret['result'] == 1: 
    #             data ={
    #                 "result":[{
    #                     "db_md5":ret['fingerprint'],    #　图片MD5
    #                     "match_degree":float(ret['distance']), #  匹配度
    #                     "detect_name":ret['user_id'],   #  user_id
    #                     "crop":[]                    #　截图的范围
    #                 }],
    #                 "is_alarm":0,                       # 0:白名单  1:黑名单   3:检测不到人脸 4:其它错误 
    #             }
    #         elif ret['result'] == 3: 
    #             data ={
    #                 "result":[{
    #                     "db_md5":ret['fingerprint'],    #　图片MD5
    #                     "match_degree":float(ret['distance']), #  匹配度
    #                     "detect_name":ret['user_id'],   #  user_id
    #                     "crop":[]                    #　截图的范围
    #                 }],
    #                 "is_alarm":3,                       # 0:白名单  1:黑名单   3:检测不到人脸 4:其它错误 
    #             }
    #         else:
    #             # 如果是陌生人
    #             data={
    #                 'result':[
    #                     {"crop":[],#图的范围
    #                         'match_degree_black':random.randint(10,30),#匹配到黑名单的最高匹配度多少
    #                         'match_degree_white':float(ret['distance']),#匹配到白名单的最高匹配度多少
    #                     }
    #                 ],
    #                         'is_alarm':2,
    #             }

    #     #2:陌生人

    #     os.remove(file_dir)
    #     return json.dumps(data)

class ActiveDogHandler(web.RequestHandler):
    # def initialize(self):
    #     self.cache_rds = _cam_user

    # @gen.coroutine
    # def get(self):
    #     r= yield self.cache_rds.insNewAlarm(self)
    #     #print "the r is:",r
    #     self.write(json.dumps(r))

    @gen.coroutine
    def post(self):
        ResultCode ="true"
        ResultDesc =""
        try:
            # data=json.loads(self.request.body)
            data=self.request.body
            # print "damon!!!!!!the alarm center is",data
            r=yield Global_lojb.active_dog(data)
        except Exception as err:
            traceback.print_exc()
            ResultCode ="false"
            ResultDesc ="{}".format(err)
        t={
        "ResultCode":ResultCode,
        "ResultDesc":ResultDesc,
        }
        # print 'the TeamHandler r is',r
        self.write(t)

class GetWorkerHandler(web.RequestHandler):
    # def initialize(self):
    #     self.cache_rds = _cam_user

    # @gen.coroutine
    # def get(self):
    #     r= yield self.cache_rds.insNewAlarm(self)
    #     #print "the r is:",r
    #     self.write(json.dumps(r))

    @gen.coroutine
    def post(self):
        ResultCode ="true"
        ResultDesc =""
        try:
            # data=json.loads(self.request.body)
            data=self.request.body
            # print "damon!!!!!!the alarm center is",data
            r=yield Global_lojb.get_worker(data)
        except Exception as err:
            traceback.print_exc()
            ResultCode ="false"
            ResultDesc ="{}".format(err)
        t={
        "ResultCode":ResultCode,
        "ResultDesc":ResultDesc,
        }
        # print 'the TeamHandler r is',r
        self.write(t)

class LoadBanlanceHandler(web.RequestHandler):
    # def initialize(self):
    #     self.cache_rds = _cam_user

    # @gen.coroutine
    # def get(self):
    #     r= yield self.cache_rds.insNewAlarm(self)
    #     #print "the r is:",r
    #     self.write(json.dumps(r))

    @gen.coroutine
    def post(self):
        ResultCode ="true"
        ResultDesc =""
        try:
            # data=json.loads(self.request.body)
            data=self.request.body
            # print "damon!!!!!!the alarm center is",data
            r=yield Global_lojb.load_banlance(data)
        except Exception as err:
            traceback.print_exc()
            ResultCode ="false"
            ResultDesc ="{}".format(err)
        t={
        "ResultCode":ResultCode,
        "ResultDesc":ResultDesc,
        }
        # print 'the TeamHandler r is',r
        self.write(t)

class TestHandler(web.RequestHandler):
    # def initialize(self):
    #     self.cache_rds = _cam_user

    # @gen.coroutine
    # def get(self):
    #     r= yield self.cache_rds.insNewAlarm(self)
    #     #print "the r is:",r
    #     self.write(json.dumps(r))

    @gen.coroutine
    def post(self):
        ResultCode ="true"
        ResultDesc =""
        try:
            # data=json.loads(self.request.body)
            data=self.request.body
            # print "damon!!!!!!the alarm center is",data
            r=yield Global_lojb.load_banlance(data)
        except Exception as err:
            traceback.print_exc()
            ResultCode ="false"
            ResultDesc ="{}".format(err)
        t={
        "ResultCode":ResultCode,
        "ResultDesc":ResultDesc,
        }
        # print 'the TeamHandler r is',r
        self.write(t)

class Application(web.Application):
    def __init__(self):
        settings = dict(
            debug = True,
            static_path=os.path.join(os.path.dirname(__file__), "static")
        )
        handlers = [
            (r"/vote_sev",AcdHandler,),
            (r"/compare",CompareHandler,),
            (r"/get_worker",GetWorkerHandler,),
            (r"/active_dog",ActiveDogHandler,),
            (r"/test", TestHandler,),
            (r"/(.*)",web.StaticFileHandler,{"path":settings['static_path']}),
        ]

        web.Application.__init__(self, handlers, **settings)


def vote_leader():
    online_sev  = Global_lojb.check_online_sev()
    print ("the online belong group is:",online_sev)
    role_type   = Global_lojb.vote_for_leader(online_sev)
    return role_type

# def role_job(role_type):  # period work
#     if role_type   == "leader":
#         Global_lojb.leader_work()
#     elif role_type == "follower":
#         Global_lojb.follower_work()

def main():
    # role_type = vote_leader()
    # role_job(role_type)
    # http_server = tornado.httpserver.HTTPServer(Application())
    http_server = Application()
    #print "the port is:",port
    http_server.listen(port)
    n_time=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
    print ('*********************ads start port:{} at the time:{}*********************'.format(port,n_time))
    tornado.ioloop.IOLoop.instance().start()

if __name__ == "__main__":
    main()


