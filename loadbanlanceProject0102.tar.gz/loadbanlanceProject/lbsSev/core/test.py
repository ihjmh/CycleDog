# import requests
# import json
# url = "http://123.58.43.34:5023/new_alarm"
# url = "http://zimg.0easy.com:6300/upload"


# def upload_pic(file_dir="pic"):
#     only_files=[f for f in os.listdir(file_dir) if os.path.isfile(os.path.join(file_dir,f))]
#     for i in only_files:
#         # print ("the pic is:","pic/"+i)
#         url = "http://52.91.10.20:6300/upload"
#         files = {'file': open("pic/"+i, 'rb')}
#         response = requests.post(url, files=files)
#         print( "the response is:",response,response.text)
#         # break
#     data= { 
#            'estate_id'          :'3522'          ,
#            'event_type'          :'flow'         ,
#            'item_id'             :'1111'            ,
#            'pic_snap_origin'     :'9acd1a52015130773d2791f9e56b523a'    ,
#            'device_id'           :'0000003522_0008'          ,
#            'create_time'         :''        ,
#            'people_count'        :''       ,
#            'car_plate_number'    :''   ,
#            'lilong_alarm_degree' :'first_degree',
#            "event_desc"          :""         ,}

#     r=requests.post(url =url,data=json.dumps(data) )

#     print (r.url)
#     print (r.text)
from itertools import cycle

lst = ["1","2","3"]

pool = cycle(lst)
while  1:
  print pool.next()
# for i in pool:
#   print 

# ((22413, '520000', '520600', '520603', '3522', 'first_degree', 'flow', datetime.datetime(2017, 8, 17, 9, 27, 50), '', '9acd1a52015130773d2791f9e56b523a', '0000003522_0008', 'default', 'unpending', None, None),)
