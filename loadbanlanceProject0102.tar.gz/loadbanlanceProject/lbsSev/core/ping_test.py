#!/usr/bin/python

import sys,os,getopt,time, select, subprocess
from threading import Thread
from IPy import IP



x=100
y=254
ping_delay=0 # in seconds
ip="192.168.1.*"

' Copyleft by WebNuLL no any right reserved ;-)'


class PingThread(Thread):
    def __init__(self,Adress):
        Thread.__init__(self) # initialize thread

        # variables
        self.Adress = Adress
        self.Status = -1

    def run(self):
        try:
            get = subprocess.getoutput("ping "+self.Adress+" -c 1")
        except OSError:
            print("Cannot execute ping, propably you dont have enough permissions to create process")
            sys.exit(1)

        Lines = get.split("\n")
        ResponseTime = False

        for line in Lines:
            # find line where is timing given
            if line.find("icmp_") > -1:
                Exp = line.split('=')
                # if response is valid
                if len(Exp) == 4:
                    self.Status = Exp[3].replace(' ms', '')
                    


def doRangeScan():
    global x, y, ping_delay, ip
    i=int(x)
    to=int(y)
    ListOfHosts = list()

    try:
        if (y-x) > 0:
            to=to+1
            while i != to:
                # use system ping and return results
                current_ip = ip.replace('*', str(i))
                # Single ping thread
                Ping = PingThread(current_ip)
                i=i+1
                # Append it to list of pinged hosts
                ListOfHosts.append(Ping)
                Ping.start()
                
            print("Adresses to scan: %1.0f" % (y-x))
            print("Ping "+ip.replace('*', "{"+str(int(x))+"-"+str(int(y))+"}"))
            print("Delay: "+str(ping_delay)+"s")

            for Host in ListOfHosts:
                Host.join()
                if Host.Status == -1:
                   print(Host.Adress+" not responding, offline")
                else:
                    print(Host.Adress+" responds in "+str(Host.Status)+"ms")

                time.sleep(ping_delay)
        else:
            print ("No ip range to scan, please select valid one with --from, --to and --ip")
    except Exception as e:
        print("There was an running the scan, propably your resources are restricted. "+str(e))
        sys.exit(1)

    
if __name__ == "__main__":
    doRangeScan()