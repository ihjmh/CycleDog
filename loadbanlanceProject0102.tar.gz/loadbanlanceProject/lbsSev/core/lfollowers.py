from lib.utils import *
from tornado import gen

err_lost_connections_with_follower = "already send 3 times ,this board no return "

@twins
class LFollowers(object):
    """docstring for LFollowers"""
    Dict_twins = dict()
    
    def __init__(self, follower_host):
        self.follower_host     = follower_host    # follower list
        self.already_deal_pics = 0                # already deal pics 
        self.no_response_pics  = 0                # already deal pics 
        self.url               = "http://"+follower_host+"/compare"
        self.max_send_pics     = 3 

    @gen.coroutine
    def compare_pic(self,data):
        """
        if self.no_response_pics > 3,delete this follower and send mail 
        """
        reusltCode = "1"
        reusltDesc = ""
        rec = ""
        if self.no_response_pics> self.max_send_pics:
            reusltCode = "3"
            reusltDesc = err_lost_connections_with_follower  
            return {
            "reusltCode":reusltCode,
            "reusltDesc":reusltDesc,
            "Result":rec
        }          
        try:
            rqt = pack_request(self.url,"post",data)
            rec = yield async_request(rqt)
        except Exception as err:
            reusltCode = "0"
            reusltDesc = err          
            self.no_response_pics +=1
        return {
            "reusltCode":reusltCode,
            "reusltDesc":reusltDesc,
            "Result":rec
        }

    # @gen.coroutine
    # def 


if __name__ == '__main__':
    main()