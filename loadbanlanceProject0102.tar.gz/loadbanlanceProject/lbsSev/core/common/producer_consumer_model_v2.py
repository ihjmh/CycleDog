import mmap
import os
import ctypes
#import cPickle as pickle
import numpy as np
import struct


class producer_consumer_model(object):
    def __init__(self, filename, mem_size, queue_size):
        
        self.filename = filename
        self.mem_size = mem_size
        self.queue_size = queue_size

        self.__INFO_OFFSET = 0
        self.__DATA_OFFSET = 128

        self.__rt = ctypes.CDLL('librt.so')
        self.__rt.sem_open.restype = ctypes.POINTER(ctypes.c_int)

        file_lock = self.__rt.sem_open(self.filename+"_file_lock", os.O_CREAT, 0666, 1)
        self.__rt.sem_wait(file_lock)
        queue_name_list = ['/dev/shm/'+self.filename+"_mmap"+"_queue_empty", '/dev/shm/'+self.filename+"_mmap"+"_queue_filled"]
        name = '/dev/shm/'+self.filename+"_mmap"+"_queue_filled"
        if (not os.path.exists(name)) or (os.path.getsize(name) < self.queue_size):
            with open(name,'wb') as f:
                f.seek(0)
                f.write('\xff' * self.queue_size*4)
        name = '/dev/shm/'+self.filename+"_mmap"+"_queue_empty"
        if (not os.path.exists(name)) or (os.path.getsize(name) < self.queue_size):
            with open(name,'wb') as f:
                f.seek(0)
                f.write(struct.pack(str(self.queue_size)+'i', *range(self.queue_size)))

        file_name_list = ['/dev/shm/'+self.filename+"_mmap"+"_data" + str(i) for i in range(self.queue_size)]
        for name in file_name_list:
            if (not os.path.exists(name)) or (os.path.getsize(name) < self.mem_size):
                with open(name,'wb') as f:
                    f.seek(0)
                    f.write("\x00" * self.mem_size);
        self.__rt.sem_post(file_lock)
        self.__rt.sem_close(file_lock)
        del file_lock
        self.__rt.sem_unlink(self.filename+"_file_lock");

        self.__file_queue_empty = open('/dev/shm/'+self.filename+"_mmap"+"_queue_empty",'rb+')
        self.__file_queue_filled = open('/dev/shm/'+self.filename+"_mmap"+"_queue_filled",'rb+')
        self.__file_data_list = [open('/dev/shm/'+self.filename+"_mmap"+"_data"+str(i),'rb+') for i in range(self.queue_size)]
        
        self.__mmap_queue_empty = mmap.mmap(self.__file_queue_empty.fileno(), self.queue_size*4);
        self.__mmap_queue_filled = mmap.mmap(self.__file_queue_filled.fileno(), self.queue_size*4);
        self.__mmap_data_list = [mmap.mmap(i.fileno(), self.mem_size) for i in self.__file_data_list]

        self.__sem_access_queue_empty = self.__rt.sem_open(self.filename+'_sem'+'_access'+"_queue_empty", os.O_CREAT, 0666, 1)
        self.__sem_access_queue_filled = self.__rt.sem_open(self.filename+'_sem'+'_access'+"_queue_filled", os.O_CREAT, 0666, 1)
        self.__sem_cnt_slot_empty = self.__rt.sem_open(self.filename+'_sem'+'_cnt'+'_slot_empty', os.O_CREAT, 0666, self.queue_size)
        self.__sem_cnt_slot_filled = self.__rt.sem_open(self.filename+"_sem"+'_cnt'+'_slot_filled', os.O_CREAT, 0666, 0)

    def producer_blocking_mode(self, data):
        self.__rt.sem_wait(self.__sem_cnt_slot_empty)

        self.__rt.sem_wait(self.__sem_access_queue_empty)
        self.__mmap_queue_empty.seek(0)
        q_e_raw = self.__mmap_queue_empty.read(self.queue_size*4)
        q_e_list = list(struct.unpack(str(self.queue_size)+'i',q_e_raw))
        fno = q_e_list[0]
        self.__mmap_queue_empty.seek(0)
        self.__mmap_queue_empty.write(q_e_raw[4:]+'\xff'*4)
        self.__rt.sem_post(self.__sem_access_queue_empty)

#        tmp = pickle.dumps(data)
#        assert(len(tmp) <= self.mem_size)
#        self.__mmap_data_list[fno].seek(0)
#        self.__mmap_data_list[fno].write(tmp)

        data = data.copy()
        assert type(data) == np.ndarray
        assert len(str(data.dtype)) <= 8
        assert len(data.shape) <= 8
        assert len(data.data) <= self.mem_size
        self.__mmap_data_list[fno].seek(self.__INFO_OFFSET)
        self.__mmap_data_list[fno].write(np.array(len(data.data),dtype='int64').data)
        self.__mmap_data_list[fno].seek(self.__INFO_OFFSET+8)
        self.__mmap_data_list[fno].write(np.array(len(data.shape),dtype='int64').data)
        self.__mmap_data_list[fno].seek(self.__INFO_OFFSET+16)
        self.__mmap_data_list[fno].write(np.array(len(str(data.dtype)),dtype='int64').data)
        self.__mmap_data_list[fno].seek(self.__INFO_OFFSET+24)
        self.__mmap_data_list[fno].write(str(data.dtype))
        self.__mmap_data_list[fno].seek(self.__INFO_OFFSET+64)
        self.__mmap_data_list[fno].write(np.array(data.shape,dtype='int64').data)
        self.__mmap_data_list[fno].seek(self.__DATA_OFFSET)
        self.__mmap_data_list[fno].write(data.data)

        
        self.__rt.sem_wait(self.__sem_access_queue_filled)
        self.__mmap_queue_filled.seek(0)
        q_f_raw = self.__mmap_queue_filled.read(self.queue_size*4)
        idx = q_f_raw.index('\xff'*4)
        self.__mmap_queue_filled.seek(idx)
        self.__mmap_queue_filled.write(struct.pack('i',fno))
        self.__rt.sem_post(self.__sem_access_queue_filled)

        self.__rt.sem_post(self.__sem_cnt_slot_filled)

    def consumer_blocking_mode(self):
        self.__rt.sem_wait(self.__sem_cnt_slot_filled)

        self.__rt.sem_wait(self.__sem_access_queue_filled)
        self.__mmap_queue_filled.seek(0)
        q_f_raw = self.__mmap_queue_filled.read(self.queue_size*4)
        q_f_list = list(struct.unpack(str(self.queue_size)+'i',q_f_raw))
        fno = q_f_list[0]
        self.__mmap_queue_filled.seek(0)
        self.__mmap_queue_filled.write(q_f_raw[4:]+'\xff'*4)
        self.__rt.sem_post(self.__sem_access_queue_filled)

#        self.__mmap_data_list[fno].seek(0)
#        tmp = self.__mmap_data_list[fno].read(self.mem_size)
#        rval = pickle.loads(tmp)
        
        self.__mmap_data_list[fno].seek(self.__INFO_OFFSET)
        data_length = np.fromstring(self.__mmap_data_list[fno].read(8), dtype='int64')
        self.__mmap_data_list[fno].seek(self.__INFO_OFFSET+8)
        data_shape_length = np.fromstring(self.__mmap_data_list[fno].read(8), dtype='int64')
        self.__mmap_data_list[fno].seek(self.__INFO_OFFSET+16)
        data_type_length = np.fromstring(self.__mmap_data_list[fno].read(8), dtype='int64')
        self.__mmap_data_list[fno].seek(self.__INFO_OFFSET+24)
        data_type = self.__mmap_data_list[fno].read(data_type_length)
        self.__mmap_data_list[fno].seek(self.__INFO_OFFSET+64)
        data_shape = np.fromstring(self.__mmap_data_list[fno].read(data_shape_length*8), dtype='int64')
        self.__mmap_data_list[fno].seek(self.__DATA_OFFSET)
        data_raw = self.__mmap_data_list[fno].read(data_length)
        rval = np.fromstring(data_raw, dtype=data_type).reshape(data_shape)

        self.__rt.sem_wait(self.__sem_access_queue_empty)
        self.__mmap_queue_empty.seek(0)
        q_e_raw = self.__mmap_queue_empty.read(self.queue_size*4)
        idx = q_e_raw.index('\xff'*4)
        self.__mmap_queue_empty.seek(idx)
        self.__mmap_queue_empty.write(struct.pack('i',fno))
        self.__rt.sem_post(self.__sem_access_queue_empty)

        self.__rt.sem_post(self.__sem_cnt_slot_empty)
        return rval





