import cv2
from interface import interface 
import time
import os
import random
import time
from lib.getconf import getConfig
from lib.utils import *
import numpy as np
import concurrent.futures

MaxNum =int( getConfig("AlgoMaxSessions","MaxNum"))
executor = concurrent.futures.ThreadPoolExecutor(MaxNum)

# while True:
#     t1=time.time()
#     time.sleep(0.1)
#     files=os.listdir('./pics/')
#     path='./pics/'+files[int(random.random())]
#     print path
#     a = cv2.imread(path)
#     # t1=time.time()
#     # print(c.process(a))
#     print("time:",time.time()-t1)
# thread_pool = ThreadPoolExecutor(MaxNum)

# @singleton
class LCompare(object):
    """docstring for LCompare"""
    def __init__(self):
        # super(LCompare, self).__init__()
        self.session_count = 0
        # self.max_num       = MaxNum
        # self.queue         = []

    def mult_threading(self,pic):
        ins_inter = interface()
        fea = ins_inter.process(pic)
        return fea

    # @gen.coroutine
    # def get_feature(self,pic):
    #     image = np.fromstring(pic,dtype = 'uint8')
    #     image = cv2.imdecode(image,1)
    #     for i in range(50):
    #         t =yield executor.submit(self.mult_threading,image)
    #     raise gen.Return(t) 

    @gen.coroutine
    def get_feature(self,pic):
        image = np.fromstring(pic,dtype = 'uint8')
        image = cv2.imdecode(image,1)
        t =yield executor.submit(self.mult_threading,image)
        raise gen.Return(t) 

if __name__ == '__main__':
    main()