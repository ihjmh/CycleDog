# vim: fileencoding=utf-8

from __future__ import print_function

import sys 
import os
import numpy as np
import cv2 
import time
import ctypes


current_fonder_path = os.path.split(os.path.realpath(__file__))[0];
producer_consumer_model_path = os.path.join(current_fonder_path,"..","common")
import sys
sys.path.append(producer_consumer_model_path)
from producer_consumer_model_v2 import producer_consumer_model


class interface():
    def __init__(self):
        self.__pcm_i = producer_consumer_model("input2mtcnn", 4096*4096, 1)
        self.__pcm_o1 = producer_consumer_model("mtcnn2output", 4096*4096, 1)
        self.__pcm_o2 = producer_consumer_model("facenet2output", 4096*4096, 1)
        self.__rt = ctypes.CDLL('librt.so')
        self.__rt.sem_open.restype = ctypes.POINTER(ctypes.c_int)
        self.__res_lock = self.__rt.sem_open("res_lock", os.O_CREAT, 0666, 1)


    def process(self, img):
        self.__rt.sem_wait(self.__res_lock)
        self.__pcm_i.producer_blocking_mode(img)
        num = self.__pcm_o1.consumer_blocking_mode()
        self.__rt.sem_post(self.__res_lock)

        if not num:
            return None
        else:
            emb = []
            for i in range(num):
                emb.append(self.__pcm_o2.consumer_blocking_mode())
            return emb

        


