from itertools import cycle
from .lfollowers import LFollowers
from lib.utils import *
import re
from .lsevping import get_online_server
from lib.getconf import getConfig
GroupInfoMaxNum = getConfig("BoardGroupInfo","MaxNum")

@singleton
class LSevStatus(object):
    """docstring for SevStatus"""
    def __init__(self, shost=""):
        self.role_type = "follower"   # "follower"/"leader" role_type ,set default follower
        self.shost  = shost           # self host
        self.cycle_voters_list =""   
        self.last_accept_time  = ""    # last time follower get job from leader,if overtime 3min,report it
        self.ptdevice_host     = []    # phonetalking list
        self.voters_list       = []         # self.voters_list
        self.leader_host       = []

    def add_follower(self,fhost):
        """
        if recv a vote ,add 1
        author: LPJ
        """
        # if fhost not in self.voters_list:
        lf_obj = LFollowers(fhost)
        lf_obj.no_response_pics = 0
        self.voters_list.append(lf_obj)
        self.cycle_voters_list = cycle(self.voters_list)
        return {
            "...":""
        }
        pass

    def delete_follower(self,lf_obj):
        """
        clear this follower
        """
        fhost = lf_obj.follower_host
        # self.voters_list.append(lf_obj)
        self.voters_list = [x for x in self.voters_list if x!=lf_obj]
        self.cycle_voters_list = cycle(self.voters_list)

    def check_online_sev(self):
        """
        scan online servers
        return online list []
        author: LPJ
        """
        ip_prefix = re.findall(r'\d+\.\d+\.\d+', self.shost)[0]
        online_hosts = get_online_server(ip_prefix,group=GroupInfoMaxNum)
        for hosts_group in online_hosts:
            if self.shost in hosts_group:
                return hosts_group

        return online_hosts

    @gen.coroutine
    def active_dog(self):
        pass


    def get_worker(self):
        return self.cycle_voters_list.next()

    def vote_for_boss(self,online_list_ip):
        """
        return boss ip,
        """
        pass

    def send_vote(self,vhost):
        """
        vote for him ,check response
        return tag
        """
        pass

    def vote_for_leader(self):
        """
        sort online_list_ip ,choose the first ip ,compare with self
        if self > first ip:
            response tag  = self.send_vote(first ip)
            if response tag = algo:
                pass
            else:
                choose the second ip 
                ....
        else:
            set self.role_type = "leader" 
        author: author: LPJ
        """
        online_list_ip = self.check_online_sev()
        for current_ip in online_list_ip:
            if self.shost > current_ip:
                print("send_vote to: ", first_ip)
                tag = self.send_vote(first_ip)
                if tag == "algo":
                    break
                else:
                    continue
            else:
                self.status == "leader"
        return self.status

    # def load_banlance(self,data):
    #     """
    #     check self.role_type
    #     if  self.role_type = ="leader":
    #         choose one algo to transfer request
    #         return fhost
    #     else:
            
    #     """
    #     lf_obj = self.cycle_voters_list.next()
    #     rec = lf_obj.compare_pic(data)
    #     reusltCode = rec["reusltCode"]
    #     if  reusltCode == "3":
    #         delete_follower(lf_obj)
    #     return rec

    def compare_pic(self,data):
        """
        contains pic and mac addr        
        communicate with algo,check answer and reply
        """
        data=json.loads(self.request.body)
        rec = do_hist_job(data)
        return rec

    # @staticmethod
    def follower_work(self):
        """
        check leader every 3 min,to see if it is alive
        """
        pass

    # @staticmethod
    def leader_work(self):
        """
        kill the algo sev on this machine,make leader use this board all resource
        """
        pass



if __name__ == '__main__':
    main()